<?php
$telegram_id = "7348934399"; // ID TELEGRAM
$id_bot = "7463543036:AAGKVCOWmk-T6BqFNfG5ckngrhNhPKZ1KtU"; // TOKEN BOT ID
?>
